import ctypes
import threading
import time

def show_error_message(title, message):
    # Define constants for message box
    MB_OK = 0x00000000
    MB_ICONERROR = 0x00000010

    # Display the message box
    ctypes.windll.user32.MessageBoxW(0, message, title, MB_OK | MB_ICONERROR)

def spam_message_boxes(count):
    threads = []
    for _ in range(count):
        thread = threading.Thread(target=show_error_message, args=("hello From Lust", "have everything going to encrypt your pc in a second"))
        threads.append(thread)
        thread.start()
        time.sleep(0.1)  # Add a slight delay to avoid overwhelming the system too quickly

    # Optional: Wait for all threads to finish
    for thread in threads:
        thread.join()

if __name__ == "__main__":
    spam_message_boxes(100)
